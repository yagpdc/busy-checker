/// <reference types="chrome" />
// Asker-configurable preferences. Stored in chrome.storage.local so both
// the popup and the chat content script see the same values.
export const DEFAULT_SETTINGS = {
    workStartHour: 9,
    workEndHour: 18,
    eventColor: "#3b82f6",
    widgetEnabled: true,
};
export async function getSettings() {
    const { settings } = await chrome.storage.local.get("settings");
    const s = (settings ?? {});
    return {
        workStartHour: clamp(s.workStartHour ?? DEFAULT_SETTINGS.workStartHour, 0, 23),
        workEndHour: clamp(s.workEndHour ?? DEFAULT_SETTINGS.workEndHour, 1, 24),
        eventColor: validHex(s.eventColor) ? s.eventColor : DEFAULT_SETTINGS.eventColor,
        widgetEnabled: typeof s.widgetEnabled === "boolean"
            ? s.widgetEnabled
            : DEFAULT_SETTINGS.widgetEnabled,
    };
}
function validHex(s) {
    return typeof s === "string" && /^#[0-9a-f]{6}$/i.test(s);
}
export async function setSettings(next) {
    await chrome.storage.local.set({ settings: next });
}
function clamp(n, lo, hi) {
    return Math.max(lo, Math.min(hi, Math.round(n)));
}
