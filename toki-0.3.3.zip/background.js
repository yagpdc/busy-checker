/// <reference types="chrome" />
import { apiFetch, clearSession, setSession } from "./api.js";
import { GOOGLE_CLIENT_ID } from "./config.js";
import { getSettings } from "./settings.js";
// Allow the content script (chat-google.ts) to read/write
// chrome.storage.session — used for the session-scoped `widgetOpen` flag.
// Default access level since Chrome 115 is TRUSTED_CONTEXTS only.
chrome.storage.session
    .setAccessLevel({ accessLevel: "TRUSTED_AND_UNTRUSTED_CONTEXTS" })
    .catch((err) => console.warn("session storage access level failed", err));
// === OAuth flow ===
const SCOPES = [
    "openid",
    "email",
    "profile",
    // calendar (full) lets us create events with Meet links via /schedule.
    "https://www.googleapis.com/auth/calendar",
    "https://www.googleapis.com/auth/directory.readonly",
];
async function signIn() {
    const redirectUri = chrome.identity.getRedirectURL();
    const url = new URL("https://accounts.google.com/o/oauth2/v2/auth");
    url.searchParams.set("client_id", GOOGLE_CLIENT_ID);
    url.searchParams.set("redirect_uri", redirectUri);
    url.searchParams.set("response_type", "code");
    url.searchParams.set("scope", SCOPES.join(" "));
    url.searchParams.set("access_type", "offline");
    url.searchParams.set("prompt", "consent");
    url.searchParams.set("include_granted_scopes", "true");
    const redirect = await chrome.identity.launchWebAuthFlow({
        url: url.toString(),
        interactive: true,
    });
    if (!redirect)
        throw new Error("Login cancelado.");
    const code = new URL(redirect).searchParams.get("code");
    if (!code)
        throw new Error("Sem code na resposta do Google.");
    const { session, user } = await apiFetch("/auth/google/callback", {
        method: "POST",
        body: JSON.stringify({ code }),
    });
    await setSession(session);
    await chrome.storage.local.set({ user });
    return { email: user.email, name: user.name };
}
// === Heartbeat ===
const HEARTBEAT_MIN_INTERVAL_MS = 30_000;
let lastHeartbeatAt = 0;
async function maybeHeartbeat(source) {
    const now = Date.now();
    if (now - lastHeartbeatAt < HEARTBEAT_MIN_INTERVAL_MS)
        return;
    lastHeartbeatAt = now;
    try {
        await apiFetch("/heartbeat", {
            method: "POST",
            body: JSON.stringify({ source }),
        });
    }
    catch (err) {
        console.warn("heartbeat failed", err);
    }
}
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    (async () => {
        switch (msg.type) {
            case "activity":
                await maybeHeartbeat(msg.source ?? "tab");
                return { ok: true };
            case "signIn":
                return await signIn();
            case "signOut":
                await clearSession();
                return { ok: true };
            case "query": {
                const s = await getSettings();
                return await apiFetch("/query", {
                    method: "POST",
                    body: JSON.stringify({
                        question: msg.question,
                        targetEmail: msg.targetEmail,
                        targetName: msg.targetName,
                        messages: msg.messages,
                        contextTargetEmail: msg.contextTargetEmail,
                        workStartHour: s.workStartHour,
                        workEndHour: s.workEndHour,
                    }),
                });
            }
            case "schedule":
                return await apiFetch("/schedule", {
                    method: "POST",
                    body: JSON.stringify({
                        targetEmail: msg.targetEmail,
                        start: msg.start,
                        end: msg.end,
                        title: msg.title,
                    }),
                });
            case "nextSlot": {
                const s = await getSettings();
                return await apiFetch("/slots/next", {
                    method: "POST",
                    body: JSON.stringify({
                        targetEmail: msg.targetEmail,
                        after: msg.after,
                        workStartHour: s.workStartHour,
                        workEndHour: s.workEndHour,
                    }),
                });
            }
        }
    })()
        .then((r) => sendResponse({ ok: true, data: r }))
        .catch((err) => sendResponse({ ok: false, error: err.message }));
    return true; // keep the channel open for async response
});
