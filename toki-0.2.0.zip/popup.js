/// <reference types="chrome" />
import { DEFAULT_SETTINGS, getSettings, setSettings } from "./settings.js";
function send(msg) {
    return new Promise((resolve, reject) => {
        chrome.runtime.sendMessage(msg, (res) => {
            if (chrome.runtime.lastError) {
                reject(new Error(chrome.runtime.lastError.message));
                return;
            }
            if (res?.ok)
                resolve(res.data);
            else
                reject(new Error(res?.error ?? "unknown_error"));
        });
    });
}
const $ = (id) => document.getElementById(id);
let chatState = { messages: [], target: null };
async function loadChatState() {
    const data = await chrome.storage.session
        .get(["chatMessages", "chatTarget"])
        .catch(() => ({}));
    const messages = Array.isArray(data.chatMessages)
        ? (data.chatMessages.filter((m) => m && (m.role === "user" || m.role === "assistant") && typeof m.content === "string"))
        : [];
    const target = (data.chatTarget ?? null);
    chatState = { messages, target };
    renderThread();
}
async function persistChatState() {
    await chrome.storage.session
        .set({ chatMessages: chatState.messages, chatTarget: chatState.target })
        .catch(() => undefined);
}
// === User / auth ===
async function refreshUser() {
    const { user, session } = await chrome.storage.local.get(["user", "session"]);
    const emailEl = $("user-email");
    const inBtn = $("sign-in");
    const outBtn = $("sign-out");
    if (session && user) {
        const u = user;
        emailEl.textContent = u.email;
        inBtn.hidden = true;
        outBtn.hidden = false;
        setGreeting(u.email);
    }
    else {
        emailEl.textContent = "";
        inBtn.hidden = false;
        outBtn.hidden = true;
        setGreeting(null);
    }
}
// === Greeting ===
function setGreeting(email) {
    const el = $("greeting-line");
    const hour = new Date().getHours();
    const period = hour < 5
        ? "Boa noite"
        : hour < 12
            ? "Bom dia"
            : hour < 18
                ? "Boa tarde"
                : "Boa noite";
    if (!email) {
        el.textContent = `${period}`;
        return;
    }
    const local = email.split("@")[0] ?? "";
    const firstChunk = local.split(/[._-]/)[0] ?? local;
    const name = firstChunk
        ? firstChunk.charAt(0).toUpperCase() + firstChunk.slice(1)
        : "";
    el.textContent = name ? `${period}, ${name}` : period;
}
// === Error display ===
function showError(msg) {
    const el = $("error");
    el.textContent = msg;
    el.hidden = false;
}
function clearError() {
    $("error").hidden = true;
}
// === View routing (home ↔ settings) ===
function showView(view) {
    $("view-home").hidden = view !== "home";
    $("view-settings").hidden = view !== "settings";
}
$("open-settings").addEventListener("click", () => {
    showView("settings");
});
$("close-settings").addEventListener("click", () => {
    showView("home");
});
// === Auth buttons ===
$("sign-in").addEventListener("click", async () => {
    clearError();
    try {
        await send({ type: "signIn" });
        await refreshUser();
    }
    catch (err) {
        showError(err.message);
    }
});
$("sign-out").addEventListener("click", async () => {
    await send({ type: "signOut" });
    await refreshUser();
});
// === Thread rendering ===
const LOADING_PHRASES = [
    "時間を整理しています...",
    "Só mais alguns segundos",
    "Carregando o futuro",
    "Harmonizando agendas",
    "Processando eventos",
    "Preparando sua próxima reunião...",
];
function pickLoadingPhrase() {
    return LOADING_PHRASES[Math.floor(Math.random() * LOADING_PHRASES.length)];
}
function el(tag, cls) {
    const node = document.createElement(tag);
    if (cls)
        node.className = cls;
    return node;
}
function appendUserBubble(text) {
    const thread = $("chat-thread");
    const node = el("div", "msg msg-user");
    node.textContent = text;
    thread.appendChild(node);
    thread.scrollTop = thread.scrollHeight;
}
function appendAssistantBubble(text) {
    const thread = $("chat-thread");
    const wrap = el("div", "msg msg-assistant");
    const kanji = el("span", "msg-kanji");
    kanji.textContent = "時";
    const bubble = el("div", "msg-bubble");
    bubble.textContent = text;
    wrap.appendChild(kanji);
    wrap.appendChild(bubble);
    thread.appendChild(wrap);
    thread.scrollTop = thread.scrollHeight;
}
function appendLoadingBubble() {
    const thread = $("chat-thread");
    const wrap = el("div", "msg msg-loading");
    wrap.dataset.loading = "true";
    const kanji = el("span", "msg-kanji");
    kanji.textContent = "時";
    const text = el("span", "loading-text");
    text.textContent = pickLoadingPhrase();
    const spinner = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    spinner.setAttribute("class", "loading-spinner");
    spinner.setAttribute("viewBox", "0 0 24 24");
    spinner.setAttribute("fill", "none");
    spinner.setAttribute("stroke", "currentColor");
    spinner.setAttribute("stroke-width", "2");
    spinner.setAttribute("stroke-linecap", "round");
    spinner.setAttribute("stroke-linejoin", "round");
    spinner.innerHTML =
        '<circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>';
    wrap.appendChild(kanji);
    wrap.appendChild(text);
    wrap.appendChild(spinner);
    thread.appendChild(wrap);
    thread.scrollTop = thread.scrollHeight;
    return wrap;
}
function renderThread() {
    const thread = $("chat-thread");
    const controls = $("thread-controls");
    const greeting = $("greeting-block");
    const contextEl = $("thread-context");
    thread.replaceChildren();
    if (chatState.messages.length === 0) {
        thread.hidden = true;
        controls.hidden = true;
        greeting.dataset.active = "false";
        return;
    }
    greeting.dataset.active = "true";
    thread.hidden = false;
    controls.hidden = false;
    for (const m of chatState.messages) {
        if (m.role === "user")
            appendUserBubble(m.content);
        else
            appendAssistantBubble(m.content);
    }
    contextEl.textContent = chatState.target
        ? `Falando sobre: ${chatState.target.name ?? chatState.target.email}`
        : "";
}
// === Ask flow ===
async function runQuery(text) {
    clearError();
    if (!text)
        return;
    const question = text;
    // Append user bubble + persist
    chatState.messages.push({ role: "user", content: question });
    if (chatState.messages.length === 1) {
        $("greeting-block").dataset.active = "true";
        $("chat-thread").hidden = false;
        $("thread-controls").hidden = false;
    }
    appendUserBubble(question);
    await persistChatState();
    // Clear the input, disable submit
    const ta = $("question");
    ta.value = "";
    $("ask").disabled = true;
    // Show loading bubble
    const loadingNode = appendLoadingBubble();
    try {
        // The history we send is everything EXCEPT the latest user message —
        // the backend appends that itself as the OpenAI "current question".
        const history = chatState.messages.slice(0, -1);
        const payload = {
            type: "query",
            question,
            messages: history,
        };
        if (chatState.target?.email) {
            payload.contextTargetEmail = chatState.target.email;
        }
        const data = await send(payload);
        loadingNode.remove();
        appendAssistantBubble(data.reply);
        chatState.messages.push({ role: "assistant", content: data.reply });
        // Carry-over target. Backend returns the resolved person (if any) so
        // the next pronoun follow-up has someone to refer to. When the turn
        // was a disambiguation (candidates), target is null — keep prior one.
        if (data.target) {
            chatState.target = data.target;
        }
        $("thread-context").textContent = chatState.target
            ? `Falando sobre: ${chatState.target.name ?? chatState.target.email}`
            : "";
        await persistChatState();
    }
    catch (err) {
        loadingNode.remove();
        const msg = err.message;
        appendAssistantBubble(`Erro: ${msg}`);
        chatState.messages.push({ role: "assistant", content: `Erro: ${msg}` });
        await persistChatState();
    }
    finally {
        $("ask").disabled = false;
        ta.focus();
    }
}
$("ask").addEventListener("click", () => {
    const q = $("question").value.trim();
    void runQuery(q);
});
$("question").addEventListener("keydown", (ev) => {
    if (ev.key === "Enter" && !ev.shiftKey) {
        ev.preventDefault();
        const q = ev.currentTarget.value.trim();
        void runQuery(q);
    }
});
// === Clear conversation ===
$("clear-chat").addEventListener("click", async () => {
    chatState = { messages: [], target: null };
    await persistChatState();
    renderThread();
    $("question").focus();
});
// === Settings ===
async function loadSettings() {
    const s = await getSettings();
    $("work-start").value = String(s.workStartHour);
    $("work-end").value = String(s.workEndHour);
    $("event-color").value = s.eventColor;
    $("widget-enabled").checked = s.widgetEnabled;
}
$("widget-enabled").addEventListener("change", async (ev) => {
    const enabled = ev.currentTarget.checked;
    const current = await getSettings().catch(() => DEFAULT_SETTINGS);
    await setSettings({ ...current, widgetEnabled: enabled });
});
$("save-settings").addEventListener("click", async () => {
    const ws = parseInt($("work-start").value, 10);
    const we = parseInt($("work-end").value, 10);
    const color = $("event-color").value;
    const widgetEnabled = $("widget-enabled").checked;
    const msg = $("settings-msg");
    msg.hidden = false;
    if (Number.isNaN(ws) ||
        Number.isNaN(we) ||
        ws < 0 ||
        ws > 23 ||
        we < 1 ||
        we > 24 ||
        ws >= we) {
        msg.dataset.error = "true";
        msg.textContent = "Início < fim, 0-24h.";
        return;
    }
    delete msg.dataset.error;
    await setSettings({
        workStartHour: ws,
        workEndHour: we,
        eventColor: color,
        widgetEnabled,
    });
    msg.textContent = "Salvo.";
});
// === Home: session-scoped widget open/close switch ===
async function loadWidgetOpen() {
    const sess = await chrome.storage.session.get("widgetOpen").catch(() => ({}));
    const open = typeof sess.widgetOpen === "boolean"
        ? (sess.widgetOpen)
        : true;
    $("widget-open").checked = open;
    updateWidgetOpenHelp(open);
}
function updateWidgetOpenHelp(open) {
    const help = $("widget-open-help");
    help.textContent = open
        ? "Aberto. Aparece nas DMs."
        : "Fechado. Reabra aqui quando quiser.";
    if (open)
        delete help.dataset.state;
    else
        help.dataset.state = "closed";
}
$("widget-open").addEventListener("change", async (ev) => {
    const open = ev.currentTarget.checked;
    updateWidgetOpenHelp(open);
    await chrome.storage.session.set({ widgetOpen: open });
});
chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "session")
        return;
    if (changes.widgetOpen) {
        const open = typeof changes.widgetOpen.newValue === "boolean"
            ? changes.widgetOpen.newValue
            : true;
        $("widget-open").checked = open;
        updateWidgetOpenHelp(open);
    }
});
// === Bootstrap ===
refreshUser();
loadChatState();
loadSettings().catch(() => {
    $("work-start").value = String(DEFAULT_SETTINGS.workStartHour);
    $("work-end").value = String(DEFAULT_SETTINGS.workEndHour);
    $("event-color").value = DEFAULT_SETTINGS.eventColor;
    $("widget-enabled").checked = DEFAULT_SETTINGS.widgetEnabled;
});
loadWidgetOpen().catch(() => {
    $("widget-open").checked = true;
    updateWidgetOpenHelp(true);
});
